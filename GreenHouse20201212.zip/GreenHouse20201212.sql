-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: r1bsyfx4gbowdsis.cbetxkdyhwsb.us-east-1.rds.amazonaws.com    Database: sn1qvahom0zodcij
-- ------------------------------------------------------
-- Server version	5.7.23-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `Comment`
--

DROP TABLE IF EXISTS `Comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Comment` (
  `CommentId` int(11) NOT NULL AUTO_INCREMENT,
  `PostId` int(11) DEFAULT NULL,
  `CommentDte` datetime DEFAULT NULL,
  `LoginId` int(11) DEFAULT NULL,
  `CommentText` text,
  PRIMARY KEY (`CommentId`),
  KEY `FK_Comment_Post` (`PostId`),
  KEY `FK_Comment_Login` (`LoginId`),
  CONSTRAINT `FK_Comment_Login` FOREIGN KEY (`LoginId`) REFERENCES `Login` (`LoginId`),
  CONSTRAINT `FK_Comment_Post` FOREIGN KEY (`PostId`) REFERENCES `Post` (`PostId`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Comment`
--

LOCK TABLES `Comment` WRITE;
/*!40000 ALTER TABLE `Comment` DISABLE KEYS */;
INSERT INTO `Comment` VALUES (1,2,'2020-12-01 00:00:00',14,'me too'),(2,1,'2020-12-09 00:02:01',14,'Well said!'),(5,7,'2020-07-29 00:00:00',14,'All appears well!'),(6,7,'2020-06-30 00:00:00',14,'okay. maybe not. ima double click the button this time'),(7,7,'2020-10-30 00:00:00',14,'okay. maybe not. ima double click the button this time'),(8,7,'2020-12-09 00:01:26',14,'Oh! I think it\'s on a page refresh- don\'t refresh the page when there\'s a message at the top'),(9,7,'2020-12-10 23:59:34',14,'Testing one more time'),(10,7,'2020-12-09 00:06:03',14,'Yes, confirmed its the refresh and not the double click. mystery solved.'),(11,7,'2020-09-13 00:00:00',14,'Okay, another test. This should only post once'),(12,7,'2020-12-09 00:11:42',14,'let\'s see if I can make a new post'),(13,7,'2020-04-27 00:00:00',14,'All is well!'),(14,9,'2020-12-10 20:29:38',4,'Why would it post twice?'),(17,9,'2020-12-11 00:23:36',2,'test'),(18,9,'2020-12-11 00:28:44',14,'another test'),(19,16,'2020-12-11 04:04:03',14,'fabaceae is the legume family! These are related to peanuts.. which I am allergic to!'),(20,16,'2020-12-11 04:24:13',4,'That is nuts!!!!'),(36,16,'2020-12-12 04:58:28',1,'I have seen many of these too, don\'t think they cause any allergies...'),(37,2,'2020-12-12 04:59:21',1,'All my kids love picking and snacking on peas! So healthy!'),(38,16,'2020-12-12 07:15:01',20,'asdasdasd'),(39,16,'2020-12-12 07:16:17',20,'asdasdasd'),(40,16,'2020-12-12 07:16:44',20,'asdasdasd'),(41,17,'2020-12-12 07:29:26',20,'test test'),(42,17,'2020-12-12 07:29:34',20,'crazy works well'),(43,17,'2020-12-12 07:33:25',NULL,'crazy works well'),(44,17,'2020-12-13 00:34:13',19,'asdasd');
/*!40000 ALTER TABLE `Comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Login`
--

DROP TABLE IF EXISTS `Login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Login` (
  `LoginId` int(11) NOT NULL AUTO_INCREMENT,
  `LoginName` varchar(50) NOT NULL,
  `HashedPwd` varchar(60) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `Gender` char(1) NOT NULL,
  `ZipCode` char(5) NOT NULL,
  `Privilege` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`LoginId`),
  UNIQUE KEY `UK_LoginName` (`LoginName`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Login`
--

LOCK TABLES `Login` WRITE;
/*!40000 ALTER TABLE `Login` DISABLE KEYS */;
INSERT INTO `Login` VALUES (1,'bowierules','$2b$10$dlz.2C.IwIsAT4ECudH4meWYZ8HFKPj8Jd25wmooqzPgwkNkmNw3K','bowierule@gmail.com','Marianna','Petrovich','F','95602',NULL),(2,'bowierul','$2b$10$dlz.2C.IwIsAT4ECudH4meWYZ8HFKPj8Jd25wmooqzPgwkNkmNw3K','bowierule@yahoo.com','M','P','F','95602',NULL),(3,'username1','$2b$10$eY8GlyxoSrfCbPrf.NwpMufAJA.Cli3IvRe5E7zu8IOmAksRtihx2','test@test.js','Garage','NJ(IF)','M','07960',NULL),(4,'asdasd','$2b$10$hB6MTmlj6efq1rxP3OprOOjMSfftsDrWdrPPvKwGR4Jgl.TybiMUi','email@email.com','David','Kim','M','12345',NULL),(5,'asdasdasdasd','$2b$10$Cwe2PPhoVwLBWn8yfHCjbet94oCdC/Eh2TTC9z3FXGrkYhj1r0iL6','asd@asd.com','test1','test2','M','11111',NULL),(6,'asdasdnj6','$2b$10$F/juydQ2e2UPUZKQI/t6A.VyZs/GsZEDHmio1L///elPyz9sc/3oC','asdasdazx@asdasd.com','zxczxc','zxczxcc','M','11111',NULL),(7,'vbvcbcvb','$2b$10$HlQjiCRv/zkXK2jQd8J/aewdnhVrbbganr29SlbgfpSMjLiypi4vC','ascsxcqe@asdcc.com','asdasdadasdzxczxc','zxczxczx','M','11111',NULL),(8,'vb0oh4','$2b$10$BaxV7QtVXnS3h9ggE4EGpehSagaU7MHGm4CWG6Dg1bqxeOwqIVAde','zxczxczc@xcesc.com','xxxzzxxcccz','zxczxczxc','M','11111',NULL),(9,'pp','$2b$10$i4X1xwR6/FuFTANCwjXDcOBLywkAv4plwsvZw8c0jOMGWz7qyINkm','ppetrovitch@gmail.com','Peter','Petrovich','M','95602',NULL),(11,'tester1','$2b$10$WOap88PmtUY2x.DcU8q9BufS7OkUNhnXSdO3iUlekT7WPLalwR0Gm','test@test.com','tester1','test','M','11111',NULL),(12,'jcruz','$2b$10$QU4.aSzhAiTvxtEzRc4PdOeOlygpYV4G3h7i1tVyAtQKpRUTgHPY2','Cruz@email.com','Jordan','Cruz','M','94015',NULL),(13,'cruz','$2b$10$jmV0nLWsJIairwDpJUVUROWHlRo6Dcqx9EFdll4pzg7wU6hapyMTW','j@email.com','Jordan','Cruz','M','94015',NULL),(14,'hollyollyoxenfree','$2b$10$7Dt4v5dv2WjUHGm3lME5cOuNWPZvljgpkG.oKyaZ9p2bTzuBYVnca','hstephens@csumb.edu','Holly','Stephens','F','95073',NULL),(15,'aaaa','$2b$10$BdLqsbKedu3Rw8oux3WNdeNVQF7I./eZEGiTqHkk/.u82lRus1ybS','aaaaa@a.com','aaaaa','aaaa','F','12345',NULL),(16,'david','$2b$10$H2MDUn6vqrggDELILc8Mb.hRJcFrBwXu45rw88K/hBBAEvRcjeJG2','d@d.com','david','david','M','11111',NULL),(17,'wopbamboo','$2b$10$PuFffcfo0.FAASovl/bB3Op3KTFsI2A2SSEtj8TVTAuUh/ZFCHZeC','yabadabadoo@gmail.com','flippy','flamboo','M','55555',NULL),(18,'meowmao','$2b$10$qQfExaOAMrwVoZLNgvJcHuljJkqrjNEp0qb00QsE2JB1ijCuXpO3S','meow@meow.com','Meow','Meow','F','33212',NULL),(19,'testuser','$2b$10$n2zM7Rk8./IB6gq0F0vj6OVNylTT8GBGjgIBStIgOX27ZCCPBYAQS','xcv09u4@sdoilvj09.com','test','user','M','11111',NULL),(20,'testuser2','$2b$10$c3YYO5I0jshOT5vRNscJ4.m/GY63MJAZ/5qYaWAHhNGPRkYqPEg1e','cxvj094tje@sdpfogjsdpvioj.com','testuser2','asdasd','M','11111',NULL);
/*!40000 ALTER TABLE `Login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `LoginPlant`
--

DROP TABLE IF EXISTS `LoginPlant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `LoginPlant` (
  `LoginId` int(11) NOT NULL,
  `PlantId` int(11) NOT NULL,
  `StartDte` date DEFAULT NULL,
  `EndDte` date DEFAULT NULL,
  `Hidden` bit(1) DEFAULT NULL,
  `FriendlyName` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `Description` varchar(500) DEFAULT NULL,
  `Hardiness` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `WaterFrequency` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Soil` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Temperature` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `LightExposure` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `Fertilization` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `SortOrder` int(11) DEFAULT NULL,
  PRIMARY KEY (`LoginId`,`PlantId`),
  KEY `FK_LoginPlant_PlantId` (`PlantId`),
  CONSTRAINT `FK_LoginPlant_LoginId` FOREIGN KEY (`LoginId`) REFERENCES `Login` (`LoginId`),
  CONSTRAINT `FK_LoginPlant_PlantId` FOREIGN KEY (`PlantId`) REFERENCES `Plant` (`PlantId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `LoginPlant`
--

LOCK TABLES `LoginPlant` WRITE;
/*!40000 ALTER TABLE `LoginPlant` DISABLE KEYS */;
INSERT INTO `LoginPlant` VALUES (2,57,NULL,NULL,NULL,NULL,'','Zone 9b : 25 to 30 (F)','','','','','',NULL),(2,60,NULL,NULL,NULL,NULL,'Tulips are the hardest flowers for this area to maintain','Zone 9b : 25 to 30 (F)','Once or twice weekly','We mostly have clay here','Too hot for them during summer, over 100F','Mostly sun','Organic manure',NULL),(2,80,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,88,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,94,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,116,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,124,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,132,NULL,NULL,NULL,NULL,'All my cukes are so huge and thick skinned!','','','','','','',NULL),(2,157,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(4,82,NULL,NULL,NULL,NULL,'My fav!!!!!!My fav!!!!!!My fav!!!!!!My fav!!!!!!My fav!!!!!!My fav!!!!!!My fav!!!!!!My fav!!!!!!My fav!!!!!!My fav!!!!!!','asdasdsdasdasd','12312313','32131312312','asdasd12asdsad','asdasdasdasdasdasdasdsd','dfgdfgdgasdasdd',NULL),(4,128,NULL,NULL,NULL,NULL,'Beautiful pink rose, blooms for couple of weeks a Beautiful pink rose, blooms for couple of weeks a Beautiful pink rose, blooms for couple of weeks a Beautiful pink rose, blooms for couple of weeks a Beautiful pink rose, blooms for couple of weeks a ','asdasdasdasdasdadsasdasd','asdasdasdasd','asdasdsadasasdsdsdsd','dasdsadsaasdasdas','asdasdsadsdfsdff34fsdvsvzxczczxc','asdasdasasasdsdasdasdasdasdasdasdsadasddasdasasdas',NULL),(4,129,NULL,NULL,NULL,NULL,'','asdasdsd','asdasdasdasdasd','sadasd','cxzczxcxasdasdasd','czxczxcxzc','',NULL),(4,130,NULL,NULL,NULL,NULL,'The Rosa indoora is the  great plant. It is really great. Like surprisingly great. Unbelieveable! IT is crazyyyyyyyyyy.','asdasd','asdasda','asdasd','','','',NULL),(4,131,NULL,NULL,NULL,NULL,'','asdasda','','asdasdas','asdasd','asdasdasd','asdasdas',NULL),(4,134,NULL,NULL,NULL,NULL,'','','','','','','',NULL),(4,136,NULL,NULL,NULL,NULL,'asd','asdsadasdasd','asd8ioh8ahscas','asdasdkljncxjnk','cloij098uojlknaf','alsknoc9w09hjq0w9','lsknclnc0q9wjfqd',NULL),(4,137,NULL,NULL,NULL,NULL,'asdasdasdasd','324wer','xvcdsff','r45srfg','asdasd','asdasd','asdasd',NULL),(4,138,NULL,NULL,NULL,NULL,'','asdasdasdasd','','','','','',NULL),(4,139,NULL,NULL,NULL,NULL,'','asdasdasdassad','','','','','',NULL),(4,146,NULL,NULL,NULL,NULL,'','','','','','','',NULL),(4,148,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(4,149,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(4,150,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(4,151,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(4,152,NULL,NULL,NULL,NULL,'','','','','','','',NULL),(12,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1),(12,31,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2),(12,32,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3),(12,35,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,4),(12,37,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,5),(12,38,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6),(12,39,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,7),(12,40,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,8),(12,42,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,9),(12,43,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,10),(12,46,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,11),(12,47,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,12),(12,48,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,13),(12,50,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,14),(12,51,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,15),(12,52,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,16),(12,53,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,17),(12,54,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,18),(13,40,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1),(13,42,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,2),(13,43,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,3),(13,46,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,4),(13,47,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,5),(13,48,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,6),(13,50,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,7),(13,51,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,8),(13,52,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,9),(13,53,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,10),(13,54,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,11),(14,52,NULL,NULL,NULL,NULL,'I don\'t actually own this','3a','weekly','dirt','warm','yes','no',NULL),(14,83,NULL,NULL,NULL,NULL,'I have a ton of these in pots on my porch','5b','weekly','potting soil','55-80F','Sunny','No',NULL),(14,84,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(14,85,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(14,86,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(14,89,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(14,90,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(14,91,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(14,96,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(14,99,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(14,119,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(14,121,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(14,123,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(14,125,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(14,127,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(14,140,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(14,143,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(14,155,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(14,158,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(17,156,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(19,138,NULL,NULL,NULL,NULL,'asdasdasdasdasdasdsd','asdasdasdasd','asdasdasdasdsad','asdasdasd','as','','',NULL),(19,160,NULL,NULL,NULL,NULL,'','','asd','','','asdasdasdasdd','',NULL),(19,161,NULL,NULL,NULL,NULL,'','asdasd','asdasdsadasdsd','asdasdasdasd','hgfghfgh','','dasdasda',NULL),(19,163,NULL,NULL,NULL,NULL,'asdasd','asdasdasd','asdasdasd','asdasds','asdasdasdsaddsdsadasd','asdasdasd','asdasdasd',NULL),(19,164,NULL,NULL,NULL,NULL,'asdasdasd','','','asdasdasd','','asdasdasdasddsa','asdasdd',NULL),(19,168,NULL,NULL,NULL,NULL,'','test','','asdsad','','','',NULL),(20,134,NULL,NULL,NULL,NULL,'vcbcvbcvb','asdasdasdasdasdasd','asdasdasda','asdasdsd','','asdasdasd','asdasd',NULL),(20,138,NULL,NULL,NULL,NULL,'asdasdasds aslidjasdisaj  aoisdasiodjas asio ooiasjd saisa jdsa dasoi jio jas sad','no wasy','','asdasdasd','asdasd','asdasd','',NULL),(20,167,NULL,NULL,NULL,NULL,'sdfsdf','asdasd','asdasd','','','','',NULL);
/*!40000 ALTER TABLE `LoginPlant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Plant`
--

DROP TABLE IF EXISTS `Plant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Plant` (
  `PlantId` int(11) NOT NULL AUTO_INCREMENT,
  `TrefleId` bigint(20) DEFAULT NULL,
  `Common_Name` varchar(100) DEFAULT NULL,
  `Scientific_Name` varchar(100) DEFAULT NULL,
  `Family` varchar(50) DEFAULT NULL,
  `Genus` varchar(50) DEFAULT NULL,
  `Image_Url` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`PlantId`),
  UNIQUE KEY `UQ_TrefleId` (`TrefleId`)
) ENGINE=InnoDB AUTO_INCREMENT=169 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Plant`
--

LOCK TABLES `Plant` WRITE;
/*!40000 ALTER TABLE `Plant` DISABLE KEYS */;
INSERT INTO `Plant` VALUES (5,103921,'Candelabra aloe','Aloe arborescens','Asphodelaceae','Aloe','https://bs.floristic.org/image/o/150830968cf7c89570250e103c0b734b8b6a1baa'),(31,139259,'Robert geranium','Geranium robertianum','Geraniaceae','Geranium','https://bs.floristic.org/image/o/15aff4c873c771b9ea9ded1648b7b23b8641a2a5'),(32,120157,'Spider plant','Chlorophytum comosum','Asparagaceae','Chlorophytum','https://bs.floristic.org/image/o/fa07d5d829363794d9dfb2ba1e5ec897fe02779c'),(35,178398,'Introduced sage','Salvia pratensis','Lamiaceae','Salvia','https://bs.floristic.org/image/o/31383040c4e961d5d60de63da2374e7f03058ccf'),(37,178369,'Lyreleaf sage','Salvia lyrata','Lamiaceae','Salvia','https://bs.floristic.org/image/o/dea850058a304c1dcf35ffed198cea9632b620f5'),(38,454292,'Black-sage','Varronia curassavica','Boraginaceae','Varronia','https://bs.floristic.org/image/o/1467e4296f3cdc891923b273b9fb3f7d85f2350f'),(39,178293,'White sage','Salvia apiana','Lamiaceae','Salvia','https://bs.floristic.org/image/o/14328766a420659419c6c05246fe36850937f474'),(40,155751,'Apple mint','Mentha suaveolens','Lamiaceae','Mentha','https://bs.floristic.org/image/o/43b51343df0a6d908fe1e0f5da1683e38ee0931d'),(42,178342,'Pineapple sage','Salvia elegans','Lamiaceae','Salvia','https://bs.floristic.org/image/o/65a062bd6800a943496397182656bcb54ba0594c'),(43,101913,'Common yarrow','Achillea millefolium','Asteraceae','Achillea','https://bs.floristic.org/image/o/d8bdcc8a8328551e6e6ce50129e8e7a871b6b3a5'),(46,925617,'Tea-oil-plant','Camellia oleifera','Theaceae','Camellia','https://bs.floristic.org/image/o/d706dd156d80626b4d40de3b730d8f1193caca90'),(47,178412,'Hummingbird sage','Salvia spathacea','Lamiaceae','Salvia','https://bs.floristic.org/image/o/41d893490fc2193d65179adb317d5fcc017132e4'),(48,159557,'Sweet basil','Ocimum basilicum','Lamiaceae','Ocimum','https://bs.floristic.org/image/o/eaf722de31333a8724b4bb72c8d51959530fae56'),(50,190734,'Lowbush blueberry','Vaccinium angustifolium','Ericaceae','Vaccinium','https://bs.floristic.org/image/o/47e11be2f432571d481550ab8d3e6fc7b9290d3b'),(51,101997,'Needle grass','Achnatherum calamagrostis','Poaceae','Achnatherum','https://bs.floristic.org/image/o/98f44bf1ff8d5831592366c2caa1dca3c971d128'),(52,178427,'Lilac sage','Salvia verticillata','Lamiaceae','Salvia','https://bs.floristic.org/image/o/a11565d8648c8264e6f998e09d46e43b93723102'),(53,111212,'Siberian-tea','Bergenia crassifolia','Saxifragaceae','Bergenia','https://bs.floristic.org/image/o/e296147faa753eac387c006db39499c8bec1c5a1'),(54,730743,'False apple mint','Mentha × rotundifolia','Lamiaceae','Mentha','https://bs.floristic.org/image/o/a94a767493de424f437f41f31f33ea68f51b7770'),(56,178290,'Woodland sage','Salvia nemorosa','Lamiaceae','Salvia','https://bs.floristic.org/image/o/5bff9c83cc5a1a965e9ad1c8a1f0915e6ae3d176'),(57,172991,'Common pear','Pyrus communis','Rosaceae','Pyrus','https://bs.floristic.org/image/o/df1f10b61c416dae1abbeb8f3e01e7fba9f5e38c'),(58,482008,'Silver ball cactus','Parodia scopa','Cactaceae','Parodia','https://bs.floristic.org/image/o/50333840d56e69c3266adc9847bcc266fdd46a31'),(59,368937,'Fence aloe','Aloiampelos tenuior','Asphodelaceae','Aloiampelos','https://bs.floristic.org/image/o/dcd20b5730942da051879bef5a3ff855e038dc3c'),(60,190185,'Didier\'s tulip','Tulipa gesneriana','Liliaceae','Tulipa','https://bs.floristic.org/image/o/67cb801e2d4f091d7ae27ad83bc0699207631ead'),(61,126587,'Moccasin flower','Cypripedium acaule','Orchidaceae','Cypripedium','https://bs.floristic.org/image/o/4f832a4e308e96db0b1cab80158285657522d68a'),(62,730781,'Peppermint','Mentha × piperita','Lamiaceae','Mentha','https://bs.floristic.org/image/o/35a4f366f30e6bc6f0a0c75f0bdf20aa43f55ee4'),(64,101905,'Fernleaf yarrow','Achillea filipendulina','Asteraceae','Achillea','https://bs.floristic.org/image/o/9768c661150e0f4ba43b897b66507c1ae78bf0f3'),(68,1236505,'Sweet yarrow','Achillea ageratum','Asteraceae','Achillea','https://bs.floristic.org/image/o/66c5ca333e2814e6863e70fe7c7f12f4fc5a500b'),(70,101894,'Moonshine yarrow','Achillea clypeolata','Asteraceae','Achillea','https://bs.floristic.org/image/o/8939f764e535c0d61230d565b6c1bbe9a0b51c9e'),(72,118868,'Douglas\' dustymaiden','Chaenactis douglasii','Asteraceae','Chaenactis','https://bs.floristic.org/image/o/cc861d2227cee1ed5336762b83a9e8859eeea193'),(73,618075,'Golden-rods','Acacia dentifera','Fabaceae','Acacia','https://bs.floristic.org/image/o/b3dbe2bd250dcad8953c8dcbd4367fbf4a48a159'),(75,219139,'Common yarrow','Ilex savannarum','Aquifoliaceae','Ilex','https://d2seqvvyy3b8p2.cloudfront.net/192934bdd126e13c500ac1d03b517adb.jpg'),(76,190772,'Darrow\'s blueberry','Vaccinium darrowii','Ericaceae','Vaccinium',''),(78,101973,'Yarrow','Achillea pannonica','Asteraceae','Achillea',''),(79,101974,'Sneezeweed','Achillea ptarmica','Asteraceae','Achillea','https://bs.floristic.org/image/o/d503950c299361478122e7e9a435f3907b6332b1'),(80,1235781,'Powderpuff-tree','Calliandra haematocephala','Fabaceae','Calliandra','https://bs.floristic.org/image/o/dc0bea30c7b332d37145183fc195108d86ac8098'),(81,1054075,'Yoshino cherry','Prunus × yedoensis','Rosaceae','Prunus','https://bs.floristic.org/image/o/e133fa5f08a03fe8bea9bdc2584c558539310a80'),(82,171391,'Japanese flowering cherry','Prunus serrulata','Rosaceae','Prunus','https://bs.floristic.org/image/o/80de0170dee93112ce7c40209d1aded7d049c76a'),(83,103997,'Lemon verbena','Aloysia citriodora','Verbenaceae','Aloysia','https://bs.floristic.org/image/o/d75bc8ee5bd0870dcd1aad32ddbd97f68e4429df'),(84,139567,'Garden vervain','Verbena × hybrida','Verbenaceae','Verbena','https://bs.floristic.org/image/o/31e3487aca5a91c55e392d51bf7ee7abdd5f415d'),(85,184129,'Light-blue snakeweed','Stachytarpheta jamaicensis','Verbenaceae','Stachytarpheta','https://bs.floristic.org/image/o/1f8a292d4fe16d077c1b618945eefabc65a715ee'),(86,1236554,'Mojave sand verbena','Abronia pogonantha','Nyctaginaceae','Abronia','https://bs.floristic.org/image/o/6d35188c28ec2fc589f1e2fcf6a5caaed7d7a3e1'),(88,166458,'Husk tomato','Physalis pubescens','Solanaceae','Physalis','https://bs.floristic.org/image/o/e1ba3bfa5d515240685df1fe458d22aa58c23d4c'),(89,167361,'Garden pea','Pisum sativum','Fabaceae','Pisum','https://bs.floristic.org/image/o/de42bcb86806a72660b5d46d06b2ae40e25610d2'),(90,147676,'Flat pea','Lathyrus sylvestris','Fabaceae','Lathyrus','https://bs.floristic.org/image/o/fda28747cf9f90431dee72b5886595b095af3a1d'),(91,147610,'Perennial pea','Lathyrus latifolius','Fabaceae','Lathyrus','https://bs.floristic.org/image/o/a2862c659ac6abadd226b1a3760c555099c6484e'),(94,121791,'Evergreen clematis','Clematis vitalba','Ranunculaceae','Clematis','https://bs.floristic.org/image/o/f4b6c4aace5217ad1fdde6a16ec7b5b4a85a8a7f'),(95,1200412,'','Placea germainii','Amaryllidaceae','Placea',''),(96,161171,'Royal fern','Osmunda regalis','Osmundaceae','Osmunda','https://bs.floristic.org/image/o/530b510f2ec8a79ef98bf30dcae43cfedf1e1be0'),(99,130506,'Male fern','Dryopteris filix-mas','Polypodiaceae','Dryopteris','https://bs.floristic.org/image/o/954e9fa90630070a2652502b37bdc6b41b00d128'),(109,124365,'Quebec hawthorn','Crataegus submollis','Rosaceae','Crataegus','https://bs.floristic.org/image/o/eaeab5342cb9b500d826963396c2d66296ac70be'),(116,113415,'Orange-ball-tree','Buddleja globosa','Scrophulariaceae','Buddleja','https://bs.floristic.org/image/o/e3273c958b16028fbe1b37dce9e144040d57f1a1'),(119,143017,'Batwing fern','Histiopteris incisa','Dennstaedtiaceae','Histiopteris','https://d2seqvvyy3b8p2.cloudfront.net/4ed0866f2ed5c9239e895670995cf2a0.jpg'),(121,780231,'Zebraplant','Goeppertia zebrina','Marantaceae','Goeppertia','https://bs.floristic.org/image/o/2663d86b6632ab14f372aabea4a104513ce3fe51'),(123,103926,'Fynbos aloe','Aloe vera','Asphodelaceae','Aloe','https://bs.floristic.org/image/o/e96639b99cee09e6b7b9faa4901ee6cd54e8519b'),(124,917047,'Coral peony','Paeonia mascula','Paeoniaceae','Paeonia','https://bs.floristic.org/image/o/cead26b00e8a2f42fcf90e35bb2816108b9a1ca4'),(125,574845,'Kangaroo fern','Phymatosorus pustulatus','Polypodiaceae','Phymatosorus','https://bs.floristic.org/image/o/c6c015aaa31d59bc04722e523effddb28605101f'),(127,698305,'Kangaroo paw','Anigozanthos flavidus','Haemodoraceae','Anigozanthos','https://bs.floristic.org/image/o/630b243356f8c15cfb840d6f2e9cb51456b6e913'),(128,175760,'French rose','Rosa gallica','Rosaceae','Rosa','https://bs.floristic.org/image/o/76cffed0aa332c6e323ff15ea15a93a23c1f671a'),(129,175745,'Chinese rose','Rosa chinensis','Rosaceae','Rosa','https://bs.floristic.org/image/o/5ffdd7134abcd7e2e386dc1ba1d09774e2264b1e'),(130,1059191,'Elliptical rose','Rosa inodora','Rosaceae','Rosa','https://bs.floristic.org/image/o/a6264ab822e0adf7cb1e89534df67fd0c439bbd1'),(131,106522,'Strawberry tree','Arbutus unedo','Ericaceae','Arbutus','https://bs.floristic.org/image/o/c41fdca72fdd5e6f6491434adf92ed5998112d94'),(132,125316,'Garden cucumber','Cucumis sativus','Cucurbitaceae','Cucumis','https://bs.floristic.org/image/o/d278dfc3db5de3552484da316ab5925b75f1bea5'),(134,171480,'Night and afternoon','Pseuderanthemum variabile','Acanthaceae','Pseuderanthemum','https://bs.floristic.org/image/o/577d0c7ad193a7d754d3e8eb50d42d43124d5bb3'),(136,144220,'Nits and lice','Hypericum drummondii','Hypericaceae','Hypericum','https://d2seqvvyy3b8p2.cloudfront.net/5443850cb93138d08f5b3e68e86df26f.jpg'),(137,108198,'Italian lords and ladies','Arum italicum','Araceae','Arum','https://bs.floristic.org/image/o/506d282b5da27820044efd8fc44f8fee1ab67fc2'),(138,137834,'European ash','Fraxinus excelsior','Oleaceae','Fraxinus','https://bs.floristic.org/image/o/84ef20b0276c3e0a6d32dd97a7b987b510feb961'),(139,997568,'Cup-and-saucer-vine','Cobaea scandens','Polemoniaceae','Cobaea','https://bs.floristic.org/image/o/28b1bdf66a86782be2dd390359f6f356a2240f91'),(140,102772,'Blue giant hyssop','Agastache foeniculum','Lamiaceae','Agastache','https://bs.floristic.org/image/o/2c90ef5ab312c2d85b675e1b6cd4d60ef3951f66'),(143,178370,'Black sage','Salvia mellifera','Lamiaceae','Salvia','https://bs.floristic.org/image/o/31cd6cef60eade4d8f4846516fd0fee6770526db'),(146,545415,'River-rose','Bauera rubioides','Cunoniaceae','Bauera','https://bs.floristic.org/image/o/3196cb5aacf64d422d5bc2d73fd101081d669e68'),(148,163001,'Bread and cheese','Paullinia pinnata','Sapindaceae','Paullinia','https://bs.floristic.org/image/o/63b5556bfe12ed7da0812e032294aab991058d05'),(149,132717,'Codlins and cream','Epilobium hirsutum','Onagraceae','Epilobium','https://bs.floristic.org/image/o/5fff85d7218e63340017bdcdcc323ef26efbce32'),(150,825125,'Red and blue water-lily','Nymphaea nouchali','Nymphaeaceae','Nymphaea','https://bs.floristic.org/image/o/99b4a15b4c791d7dec00b01e21fa2fbe30ef608a'),(151,171335,'Korean cherry','Prunus maximowiczii','Rosaceae','Prunus','https://d2seqvvyy3b8p2.cloudfront.net/f97f07f767ae524f927679b649e9dd68.jpg'),(152,171318,'Hollyleaf cherry','Prunus ilicifolia','Rosaceae','Prunus','https://bs.floristic.org/image/o/0fd9db9c9240c2fd3ecd3389a4d6029304e3f80c'),(155,178321,'Purple sage','Salvia dorrii','Lamiaceae','Salvia','https://bs.floristic.org/image/o/02d73397171474db13b116f419e37a50d17faab8'),(156,144423,'Hairy cat\'s ear','Hypochaeris radicata','Asteraceae','Hypochaeris','https://d2seqvvyy3b8p2.cloudfront.net/6d0af0bfb352c0254ea3019d7b6a5844.jpg'),(157,186154,'Common lilac','Syringa vulgaris','Oleaceae','Syringa','https://bs.floristic.org/image/o/70f8c6bddf331adcbef7493a72f9cbff83afad92'),(158,178407,'Europe sage','Salvia sclarea','Lamiaceae','Salvia','https://bs.floristic.org/image/o/2ef5b4d13e1b3538e5d070d4d319ef82f7d3ad61'),(160,182561,'Jerusalem cherry','Solanum pseudocapsicum','Solanaceae','Solanum','https://bs.floristic.org/image/o/88eac06dd733326e2c5390262990f1cc046e12d4'),(161,815989,'Australian brush-cherry','Syzygium australe','Myrtaceae','Syzygium','https://bs.floristic.org/image/o/ee963d36b9d4a4a7b4a49bb4a8aac1fffd28ee2b'),(163,374158,'Mother fern','Asplenium bulbiferum','Aspleniaceae','Asplenium','https://bs.floristic.org/image/o/f1cad1a7af7a4097e9af2ed716fda741e4853bb3'),(164,1124761,'Yesterday-today-and-tomorrow','Brunfelsia australis','Solanaceae','Brunfelsia','https://bs.floristic.org/image/o/70c6d0c0023aef0e079dcbf2911133e0bdca6644'),(167,105986,'Adam and eve','Aplectrum hyemale','Orchidaceae','Aplectrum','https://bs.floristic.org/image/o/5d347fc0abae1884d5546ab7d094430417b62d18'),(168,928893,'Kudu berry','Pseudolachnostylis maprouneifolia','Phyllanthaceae','Pseudolachnostylis','https://bs.floristic.org/image/o/64969d374afd26e0c78cd69ad7d45a7e129cf412');
/*!40000 ALTER TABLE `Plant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Post`
--

DROP TABLE IF EXISTS `Post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Post` (
  `PostId` int(11) NOT NULL AUTO_INCREMENT,
  `PlantId` int(11) DEFAULT NULL,
  `PostDte` datetime DEFAULT NULL,
  `Topic` varchar(100) DEFAULT NULL,
  `PostText` text CHARACTER SET latin1,
  `Image_Url` varchar(200) DEFAULT NULL,
  `LoginId` int(11) NOT NULL,
  PRIMARY KEY (`PostId`),
  KEY `FK_Post_PlantId` (`PlantId`),
  KEY `FK_Post_LoginId` (`LoginId`),
  CONSTRAINT `FK_Post_LoginId` FOREIGN KEY (`LoginId`) REFERENCES `Login` (`LoginId`),
  CONSTRAINT `FK_Post_PlantId` FOREIGN KEY (`PlantId`) REFERENCES `Plant` (`PlantId`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Post`
--

LOCK TABLES `Post` WRITE;
/*!40000 ALTER TABLE `Post` DISABLE KEYS */;
INSERT INTO `Post` VALUES (1,88,'2020-12-08 02:16:23','My tomato is still green','dfdgfsdfgsdfgsd\r\ndsfgsdfg\r\nsdfgsd\r\ndfgd\r\nfg','public/uploads/file1-1607393783153.gif',2),(2,88,'2020-12-08 02:21:18','I have this plant','How about you?','https://csumb-marianna.s3.us-west-1.amazonaws.com/Husk-Tomato-Poster.jpg',2),(7,89,'2020-12-09 06:04:09','Testing duplicates','I made my last post twice because I thought it didn\'t work the first time.. I think. Posting again and only once! Just for my sanity. I don\'t actually own any garden peas. Attaching a picture of my cat. I water daily.','https://csumb-marianna.s3.us-west-1.amazonaws.com/peas.jpg',14),(9,121,'2020-12-10 06:23:11','Testing again','I am expecting this to post twice.','https://csumb-marianna.s3.us-west-1.amazonaws.com/calathea-zebrina-care-23-783x440.jpg',14),(13,60,'2020-12-11 02:04:42','How do you water your tulips?','It is very dry in my area and tulips are not doing well. Please advice!','https://csumb-marianna.s3.us-west-1.amazonaws.com/1607652281871-wilted_tulip_by_livelaughlove190_d2owm4s-fullview.jpg',2),(14,128,'2020-12-11 02:10:33','Look at how beautiful my rose is!','Roses are photophilous. For their maintenance, southeast or southwest windows are best suited. Windows facing south are less suitable, because in the summer the roses are too hot for them, and this leaves leaves smaller for plants and flowers, which also fade and fall off faster. East and west windows are also suitable for roses, but if your apartment faces the north, it is better not to plant these plants. In your case, you can think about artificial lighting. In this light, many plants bloom beautifully, especially with fluorescent lamps. Even if there is no natural lighting at all, but there is a properly organized artificial lighting, the plants will grow and can bloom well. Therefore, if the plant does not bloom, then, first of all, you need to think about whether there is enough light for it. You should also take into account the length of daylight hours, usually it is not less than 10-12 hours. Lamps above plants turn on when it starts to get dark outside until midnight. It is necessary to have fluorescent lamps at a distance not exceeding thirty centimeters from the tops of plants. The skillful use of highlighting allows you to keep your roses in bloom until winter, even until the New Year. Perhaps this additional illumination on the north and north-east windows will give its positive results, because plants also have problems on sunny windows, because on such windows, especially in summer, flower pots can be very hot by the sun. The earth in them dries very quickly, and the roots of the plants overheat. Roses are very sensitive to such overheating, and in order to avoid it, it is better to pick up light-colored containers for plants, and in the hot season (May to September) cover the walls of the pots from direct sunlight with white paper.','https://csumb-marianna.s3.us-west-1.amazonaws.com/1607652632718-1452973682703.jpeg',4),(16,80,'2020-12-11 03:57:27','These are very popular in the area where I live','Have you seen any by you? Do they cause allergies, I wonder?','https://csumb-marianna.s3.us-west-1.amazonaws.com/1607658377382-334cb5d7797dc9c45bdb8769b43c12c7.jpg',2),(17,134,'2020-12-12 07:20:34','holy cow this works','test test','https://csumb-marianna.s3.us-west-1.amazonaws.com/1607757634261-tropical-houseplant.gif',20);
/*!40000 ALTER TABLE `Post` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-12-12 16:49:11
